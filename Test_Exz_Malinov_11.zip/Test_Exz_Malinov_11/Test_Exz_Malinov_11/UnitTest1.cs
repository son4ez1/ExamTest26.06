﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Malinov_Exz_11;

namespace Test_Exz_Malinov_11
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int year = 2023;
            int group = 123;
            string fio = "Иванов Иван Иванович";

            //ожидание
            string expected = "2023.123.ИИИ";

            //фактический результат
            string actual = StudentNumberGenerator.GetStudNumber(year, group, fio);

            //сравнение двух результатов
            Assert.AreEqual(expected, actual);

        }
    }
}

