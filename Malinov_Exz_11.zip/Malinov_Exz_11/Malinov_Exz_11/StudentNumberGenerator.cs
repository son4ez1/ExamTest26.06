﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Malinov_Exz_11
{
    public class StudentNumberGenerator
    {
        public static string GetStudNumber(int year, int group, string fio)
        {
            // Извлечение первой буквы фамилии, имени и отчества
            string initials = string.Join("", fio.Split(' ').Select(x => x[0]));
            // Формирование номера студенческого билета
            return $"{year}.{group:D3}.{initials}";
        }

    }
}
